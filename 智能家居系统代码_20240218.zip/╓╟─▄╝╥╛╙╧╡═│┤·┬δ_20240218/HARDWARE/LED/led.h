#ifndef __LED_H
#define __LED_H	 
#include "sys.h"
#define LED1 PAout(15)// PA15
void LED_Init(void);//��ʼ��		 				    
#endif
